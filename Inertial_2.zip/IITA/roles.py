# -*- coding: utf-8 -*-
from math_utils.point import Point
from math_utils.angle import degrees

class Forwarder:
    def applyOn(self, robot, snapshot):
        if snapshot.color == "B":
            equipo = 1
        else:
            equipo = -1

        if snapshot.ball != None:
            ball = snapshot.ball.position
        else:
            ball = Point.ORIGIN
        
        x,y = 0,0
        if robot.teamMessages:
            x,y = max(robot.teamMessages)

        range_c = equipo * 0.0
        #range_d = equipo * -0.35
        #range_e = Point(ball.x, equipo * -0.5)

        target = Point(ball.x, equipo * -0.35)

        default = Point(equipo * -0.25, equipo * -0.25)

        distance_x = robot.getPosition().x - x
        distance_y = robot.getPosition().y - y

        side = equipo * 0.0
        test = 0.35

        objective_a = Point(-0.1, equipo * 0.8)
        objective_b = Point(0.1, equipo * 0.8)

        if y > range_c:
            if robot.getPosition().dist(target) < 0.01:
                robot.lookAtAngle(degrees(90))
            else:
                robot.moveToPoint(target)

        elif y < range_c:
            if snapshot.ball != None:
                if distance_x < 0.1 and distance_y < 0.1:
                    if y < test:
                        if x > side:
                            robot.moveToPoint(objective_a)
                        else:
                            robot.moveToPoint(objective_b)
                    else:
                        if x > side:
                            robot.moveToPoint(objective_a)
                        else:
                            robot.moveToPoint(objective_b)
                else:
                    robot.moveToBall()
            else:
                robot.moveToPoint(default)

        else:
            if snapshot.ball != None:
                robot.moveToBall()
            else:
                robot.moveToPoint(default)



class Midfielder:
    def applyOn(self, robot, snapshot):
        if snapshot.color == "B":
            equipo = 1
        else:
            equipo = -1

        if snapshot.ball != None:
            ball = snapshot.ball.position
        else:
            ball = Point.ORIGIN
        
        x,y = 0,0
        if robot.teamMessages:
            x,y = max(robot.teamMessages)

        #range_b = equipo * 0.35
        range_c = equipo * 0.0
        range_d = equipo * -0.35

        target = Point(ball.x, equipo * 0)

        distance_x = robot.getPosition().x - x
        distance_y = robot.getPosition().y - y

        side = equipo * 0.0
        test = 0.35

        objective_a = Point(-0.1, equipo * 0.8)
        objective_b = Point(0.1, equipo * 0.8)
        center = Point(0.0, 0.0)

        if y < range_d:
            if robot.getPosition().dist(target) < 0.01:
                robot.lookAtAngle(degrees(90))
            else:
                robot.moveToPoint(target)

        elif range_d < y < range_c:
            if snapshot.ball != None:
                if distance_x < 0.1 and distance_y < 0.1:
                    if y < test:
                        if x > side:
                            robot.moveToPoint(objective_a)
                        else:
                            robot.moveToPoint(objective_b)
                    else:
                        if x > side:
                            robot.moveToPoint(objective_a)
                        else:
                            robot.moveToPoint(objective_b)
                else:
                    robot.moveToBall()
            else:
                robot.moveToPoint(Point.ORIGIN)

        elif y > range_c:
            if snapshot.ball != None:
                if distance_x < 0.1 and distance_y < 0.1:
                    robot.moveToPoint(center)
                else:
                    robot.moveToBall()
            else:
                robot.moveToPoint(Point.ORIGIN)

        else:
            if snapshot.ball != None:
                robot.moveToBall()
            else:
                robot.moveToPoint(Point.ORIGIN)
            
            
class Goalkeeper:
    def applyOn(self, robot, snapshot):
        if snapshot.color == "B":
            equipo = 1
        else:
            equipo = -1

        if snapshot.ball != None:
            ball = snapshot.ball.position
        else:
            ball = Point.ORIGIN

        range_a = equipo * 0.5
        range_b = equipo * 0.35

        target = Point(ball.x, equipo * 0.55)

        left_target= Point(equipo * 0.3, ball.y)
        right_target= Point(equipo * -0.3, ball.y)

        x,y = 0,0
        if robot.teamMessages:
            x,y = max(robot.teamMessages)

        if y <= range_b:
            if x <= 0.35 and x >= -0.35:
                if robot.getPosition().dist(target) < 0.01:
                    robot.lookAtAngle(degrees(90))
                else:
                    robot.moveToPoint(target)
            else:
                robot.lookAtPoint(ball)

        elif range_b < y < range_a:
            if x < 0.35 and x > -0.35:
                robot.moveToBall()
            else:
                robot.lookAtPoint(ball)
        
        elif y >= range_a:
            if x < 0.35 and x > -0.35:
                if robot.getPosition().dist(target) < 0.01:
                    robot.lookAtAngle(degrees(90))
                else:
                    robot.moveToPoint(target)
                        
            elif x > 0.35:
                if robot.getPosition().dist(left_target) < 0.01:
                    robot.lookAtAngle(degrees(90))
                else:
                    robot.moveToPoint(left_target)

            elif x < -0.35:
                if robot.getPosition().dist(right_target) < 0.01:
                    robot.lookAtAngle(degrees(90))
                else:
                    robot.moveToPoint(right_target)

        else:
            if robot.getPosition().dist(target) < 0.01:
                robot.lookAtAngle(degrees(90))
            else:
                robot.moveToPoint(target)